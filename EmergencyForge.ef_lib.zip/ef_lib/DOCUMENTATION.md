# EF Library - UI Framework Documentation

> Die gepflegte Fassung dieser Doku steht unter [docs.emergencyforge.de/ef-lib](https://docs.emergencyforge.de/ef-lib/), mit einer durchsuchbaren [Referenz aller Exports und Events](https://docs.emergencyforge.de/referenz/ef-lib/). Diese Datei liegt für den Offline-Gebrauch bei und kann hinterherhinken.

## Installation

1. Kopiere den `ef_lib` Ordner in deinen FiveM `resources` Ordner
2. Füge `ensure ef_lib` in deine `server.cfg` ein
3. Starte den Server neu

---

## Konfiguration

Bearbeite `config.lua` um die Grundeinstellungen anzupassen:

```lua
Config = {}

-- Akzentfarbe (HEX Code)
Config.AccentColor = '#f0500a'

-- Sprache der eingebauten Texte: 'de' oder 'en'
Config.Locale = 'de'

-- Standardtasten für Anfragen (Spieler können sie in den FiveM-Tastenbelegungen ändern)
Config.RequestKeys = { accept = 'Y', decline = 'N' }

-- Spielbild hinter Dialogen, Minispielen und Radialmenü verwischen
-- Die NUI kann das Spiel selbst nicht verwischen, dafür nutzt ef_lib den Screen-Blur von GTA
Config.ScreenBlur = true

-- Demo-Menü aktivieren (in Produktion auf false setzen)
Config.EnableDemo = true

-- Maus-Cursor in Menüs anzeigen (globaler Standard)
-- true = Maus + Tastatur (Cursor sichtbar, Items klickbar)
-- false = Nur Tastatur (kein Cursor, Spieler behält Kamerasteuerung)
-- Kann pro Menü überschrieben werden: OpenMenu({ showCursor = true/false })
Config.ShowCursor = true

-- Spielerbewegung während Menü erlauben (globaler Standard)
-- true = Spieler kann sich bewegen/umsehen während Menü offen ist
-- false = Spieler ist eingefroren während Menü offen ist
-- Kann pro Menü überschrieben werden: OpenMenu({ allowMove = true/false })
Config.AllowMove = true

-- Taste für Demo-Menü (nur wenn EnableDemo = true)
Config.MenuKey = 'F2'
```

### Verfügbare Farben (Beispiele)
| Farbe | HEX Code |
|-------|----------|
| EmergencyForge-Orange (Standard) | `#f0500a` |
| Blau | `#3b82f6` |
| Rot | `#ef4444` |
| Grün | `#22c55e` |
| Lila | `#a855f7` |
| Orange | `#f97316` |
| Gelb | `#eab308` |

### Cursor-Steuerung (`Config.ShowCursor`)

| Wert | Steuerung | Beschreibung |
|------|-----------|-------------|
| `true` | Maus + Tastatur | Cursor sichtbar, Items klickbar. Standard-Verhalten. |
| `false` | Nur Tastatur | Kein Cursor, Spieler behält Kamerasteuerung (z.B. für Kleidung/Wardrobe-Menüs). |

Dies ist der **globale Standard** für alle Menüs. Einzelne Menüs können den Wert mit `showCursor` überschreiben:

```lua
-- Globaler Standard aus Config.ShowCursor wird verwendet
exports.ef_lib:OpenMenu({ title = 'Normal', items = { ... } })

-- Überschreibt den globalen Standard für dieses Menü
exports.ef_lib:OpenMenu({ title = 'Wardrobe', showCursor = false, items = { ... } })
```

**Priorität:** `menuData.showCursor` (wenn gesetzt) > `Config.ShowCursor` > `true` (Fallback)

### Bewegungssteuerung (`Config.AllowMove`)

| Wert | Verhalten | Beschreibung |
|------|-----------|-------------|
| `true` | Bewegung erlaubt | Spieler kann sich bewegen und umsehen während Menü offen ist. |
| `false` | Bewegung gesperrt | Spieler ist eingefroren während Menü offen ist (klassisches UI-Verhalten). |

Einzelne Menüs können den Wert mit `allowMove` überschreiben:

```lua
-- Spieler kann sich bewegen
exports.ef_lib:OpenMenu({ title = 'Wardrobe', allowMove = true, items = { ... } })

-- Spieler ist eingefroren
exports.ef_lib:OpenMenu({ title = 'Shop', allowMove = false, items = { ... } })
```

**Priorität:** `menuData.allowMove` (wenn gesetzt) > `Config.AllowMove` > `true` (Fallback)

---

## Callback System

Das Callback-System ermöglicht sichere Client-Server-Kommunikation. Der Client kann Server-Funktionen aufrufen und auf deren Ergebnis warten (synchron) oder asynchron reagieren.

### Server: Callback registrieren

```lua
exports.ef_lib:RegisterCallback('meinScript:getPlayerData', function(source, arg1, arg2)
    -- source = Server-ID des anfragenden Spielers
    -- arg1, arg2, ... = Parameter die der Client mitgibt
    
    local data = { name = 'Max', money = 50000 }
    return data
end)
```

### Server: Callback mit mehreren Rückgabewerten

```lua
exports.ef_lib:RegisterCallback('meinScript:buyItem', function(source, itemName, amount)
    if not itemName then
        return false, 'Kein Item angegeben'
    end
    
    -- Logik hier...
    return true, 'Erfolgreich gekauft: ' .. amount .. 'x ' .. itemName
end)
```

### Client: Callback aufrufen (blockierend / await)

```lua
-- Einfacher Callback
local data = exports.ef_lib:CallbackAwait('meinScript:getPlayerData')
print(data.name, data.money)

-- Mit Parametern und mehreren Rückgabewerten
local success, msg = exports.ef_lib:CallbackAwait('meinScript:buyItem', 'bandage', 5)
if success then
    print('OK:', msg)
else
    print('Fehler:', msg)
end
```

**Wichtig:** `CallbackAwait` blockiert den aktuellen Thread bis die Antwort kommt (max. 30 Sekunden Timeout). Verwende es in `CreateThread` oder Event-Handlern.

**Hinweis:** Exports verlieren alles hinter einem `nil`. Ein `nil` vor einem weiteren Rückgabewert kommt deshalb als `false` an: Aus `return nil, 'Fehler'` wird `false, 'Fehler'`. Prüfe Fehler mit `if not success`, nicht mit `== nil`.

### Client: Callback aufrufen (asynchron / non-blocking)

```lua
exports.ef_lib:CallbackAsync('meinScript:getPlayerData', function(data)
    -- Wird aufgerufen wenn der Server antwortet
    print('Antwort erhalten:', data.name)
end)

-- Code hier läuft SOFORT weiter!
print('Warte nicht auf Antwort...')
```

### Server: Callback entfernen

```lua
exports.ef_lib:UnregisterCallback('meinScript:getPlayerData')
```

**Hinweis:** Callbacks werden automatisch aufgeräumt wenn die registrierende Resource gestoppt wird.

### Migration von ox_lib

```lua
-- VORHER (ox_lib):
lib.callback.register('name', function(source, ...) ... end)
local result = lib.callback.await('name', false, arg1, arg2)

-- NACHHER (ef_lib):
exports.ef_lib:RegisterCallback('name', function(source, ...) ... end)
local result = exports.ef_lib:CallbackAwait('name', arg1, arg2)
-- Hinweis: Der 2. Parameter (false/delay) entfällt komplett!
```

---

## Menü System

### Menü öffnen

```lua
exports.ef_lib:OpenMenu({
    title = 'Menü Titel',
    showCursor = true,      -- Maus-Cursor anzeigen (optional, Standard: true)
    items = {
        -- Items hier
    }
})
```

| Parameter | Typ | Standard | Beschreibung |
|-----------|-----|----------|-------------|
| `title` | string | — | Titel des Menüs |
| `subtitle` | string | — | Kleine Zeile unter dem Titel (optional, auch bei Untermenüs) |
| `items` | table | — | Array von Menu Items |
| `showCursor` | boolean | `Config.ShowCursor` | Maus-Cursor anzeigen. Überschreibt den globalen `Config.ShowCursor` Wert. Auf `false` setzen für Menüs die Kamerasteuerung brauchen (z.B. Kleidung/Wardrobe) |
| `allowMove` | boolean | `Config.AllowMove` | Spielerbewegung erlauben. Überschreibt den globalen `Config.AllowMove` Wert. Auf `false` setzen um den Spieler einzufrieren. |

**Hinweis:** Bei `showCursor = false` behält der Spieler die Maus-/Kamerasteuerung. Navigation erfolgt über Tastatur (Pfeiltasten / WASD).

### Menü schließen

```lua
exports.ef_lib:CloseMenu()
```

### Menü Status prüfen

```lua
local isOpen = exports.ef_lib:IsMenuOpen()
```

### Menu Item aktualisieren

Aktualisiert ein bestehendes Menu Item zur Laufzeit (z.B. um Min/Max eines Number-Items zu ändern).

```lua
exports.ef_lib:UpdateMenuItem('item_id', {
    current = 0,
    max = 15,
    description = '16 verfügbar',
})
```

| Parameter | Typ | Beschreibung |
|-----------|-----|-------------|
| `id` | string | Die ID des Items das aktualisiert werden soll |
| `updates` | table | Felder die aktualisiert werden sollen (current, max, min, description, etc.) |

### Menü Navigation (programmatisch)

Erlaubt es, das Menü von außen zu navigieren (z.B. über WASD-Forwarding vom Game Client).

```lua
exports.ef_lib:NavigateMenu('up')     -- Nach oben
exports.ef_lib:NavigateMenu('down')   -- Nach unten
exports.ef_lib:NavigateMenu('left')   -- Links / Wert verringern / Zurück
exports.ef_lib:NavigateMenu('right')  -- Rechts / Wert erhöhen / Aktivieren
exports.ef_lib:NavigateMenu('back')   -- Zurück zum vorherigen Menü
exports.ef_lib:NavigateMenu('close')  -- Menü schließen
```

---

## Item Typen

### 1. Button (Standard)

Normaler klickbarer Menüeintrag mit Pfeil-Indikator.

```lua
{
    id = 'unique_id',           -- Eindeutige ID (erforderlich)
    label = 'Button Text',      -- Angezeigter Text (erforderlich)
    description = 'Info Text',  -- Beschreibung unter dem Label (optional)
    icon = '🎮',                -- Emoji Icon (optional)
    disabled = false,           -- Deaktiviert (optional)
    data = { custom = 'data' }  -- Eigene Daten (optional)
}
```

---

### 2. Checkbox

```lua
{
    id = 'unique_id',
    label = 'Checkbox Text',
    type = 'checkbox',
    checked = true,
    disabled = false
}
```

---

### 3. Input

```lua
{
    id = 'unique_id',
    label = 'Input Label',
    type = 'input',
    placeholder = 'Platzhalter...',
    value = '',
    disabled = false
}
```

---

### 4. Submenu

```lua
{
    id = 'unique_id',
    label = 'Submenu Label',
    description = 'Beschreibung',
    submenu = {
        title = 'Untermenü Titel',
        items = { ... }
    }
}
```

**Navigation:**
- `Enter` oder `Pfeil Rechts`: Submenu öffnen
- `ESC`, `Backspace` oder `Pfeil Links`: Zurück zum vorherigen Menü

---

### 5. Select

```lua
{
    id = 'unique_id',
    label = 'Select Label',
    type = 'select',
    value = 'option1',
    options = { 'option1', 'option2', 'option3' },
    disabled = false
}
```

Soll im Menü ein anderer Text stehen als der Wert, der zurückkommt, geht jede Option auch als Tabelle:

```lua
options = { { value = 'left', label = 'Links' }, { value = 'right', label = 'Rechts' } }
```

---

### 6. Number (Zahlenwähler)

Kompakter Zahlenwähler mit Links/Rechts-Pfeilen (`< Nr >`).

```lua
{
    id = 'unique_id',
    label = 'Drawable',
    description = '662 verfügbar',
    type = 'number',
    min = 0,               -- Minimaler Wert (optional, Standard: -∞)
    max = 661,              -- Maximaler Wert (optional, Standard: ∞)
    step = 1,               -- Schrittweite (optional, Standard: 1)
    current = 0             -- Aktueller Wert (optional, Standard: min oder 0)
}
```

**Navigation:**
- `← / A`: Wert verringern
- `→ / D`: Wert erhöhen
- Pfeiltasten im UI klickbar

**Event-Daten:**
```lua
if data.type == 'number' then
    print('Aktueller Wert:', data.value) -- Gibt den aktuellen Zahlenwert zurück
end
```

---

### 7. Confirmation (Bestätigungsdialog)

```lua
{
    id = 'unique_id',
    label = 'Gefährliche Aktion',
    confirm = true              -- Einfache Bestätigung
}
```

**Mit eigenen Texten:**
```lua
{
    id = 'unique_id',
    label = 'Löschen',
    confirm = {
        title = 'Wirklich löschen?',
        message = 'Diese Aktion kann nicht rückgängig gemacht werden.',
        confirmLabel = 'Ja, löschen',
        cancelLabel = 'Abbrechen'
    }
}
```

---

## Events

### Menu Action Event

```lua
AddEventHandler('ef_lib:menuAction', function(data)
    print('Item ID:', data.id)
    print('Item Type:', data.type)
    print('Item Label:', data.label)

    if data.type == 'checkbox' then
        print('Checked:', data.checked)
    end

    if data.type == 'input' then
        print('Value:', data.value)
    end

    if data.type == 'number' then
        print('Value:', data.value)
    end

    if data.data then
        print('Custom Data:', json.encode(data.data))
    end
end)
```

---

## Benachrichtigungen

### Client-seitig

```lua
exports.ef_lib:SendNotification(type, title, message, duration)
```

| Parameter | Typ | Beschreibung |
|-----------|-----|--------------|
| type | string | `'success'`, `'error'`, `'warning'`, `'info'` |
| title | string | Titel der Benachrichtigung |
| message | string | Nachrichtentext |
| duration | number | Anzeigedauer in ms (Standard: 5000) |

### Server-seitig

```lua
-- An einen Spieler
exports.ef_lib:SendNotification(source, 'success', 'Titel', 'Nachricht', 5000)

-- An alle Spieler
exports.ef_lib:SendNotificationToAll('info', 'Server', 'Nachricht an alle', 10000)
```

---

## Button Hints (Interaktions-Hinweise)

### Hint anzeigen

```lua
exports.ef_lib:ShowHint('E', 'Shop öffnen', 'shop_hint')
```

### Hint verstecken

```lua
exports.ef_lib:HideHint('shop_hint')
exports.ef_lib:HideAllHints()
```

### Mehrere Hints gleichzeitig

```lua
exports.ef_lib:ShowHint('F', 'Einsteigen', 'vehicle_enter')
exports.ef_lib:ShowHint('H', 'Kofferraum', 'vehicle_trunk')

-- Beim Verlassen der Zone
exports.ef_lib:HideAllHints()
```

---

## Akzentfarbe zur Laufzeit ändern

```lua
exports.ef_lib:SetAccentColor('#ff0000')
```

---

## Client-Einstellungen (UI Settings)

```lua
exports.ef_lib:OpenMenu({
    title = 'Mein Menü',
    items = {
        { id = 'option1', label = 'Option 1' },
        exports.ef_lib:GetUISettingsMenu(),
    }
})
```

---

## Tastenkombinationen (In-Game)

| Taste | Funktion |
|-------|----------|
| ↑ / W | Nach oben navigieren |
| ↓ / S | Nach unten navigieren |
| Enter / → / D | Item aktivieren / Submenu öffnen |
| ← / A | Zahlenwert verringern (bei Number-Typ) / Zurück |
| → / D | Zahlenwert erhöhen (bei Number-Typ) |
| ESC / Backspace | Zurück (im Submenu) / Menü schließen |
| / | Suche öffnen (bei >5 Items) |

**Hinweis:** Bei `showCursor = false` werden WASD-Tasten als Navigation an das Menü weitergeleitet, gleichzeitig werden sie an den Game Client durchgereicht (z.B. für Kamerasteuerung).

---

## Als Library nutzen

### 1. Dependency hinzufügen

```lua
dependencies { 'ef_lib' }
```

### 2. Demo deaktivieren

In `ef_lib/config.lua`:
```lua
Config.EnableDemo = false
```

### 3. Alle Exports auf einen Blick

**Client:**
```lua
-- Callback System
exports.ef_lib:CallbackAwait(name, ...)           -- Blockierend
exports.ef_lib:CallbackAsync(name, callback, ...)  -- Asynchron

-- Menü
exports.ef_lib:OpenMenu(menuData)                  -- Menü öffnen (menuData.showCursor optional)
exports.ef_lib:CloseMenu()                         -- Menü schließen
exports.ef_lib:ToggleMenu(show)                    -- Menü ein-/ausblenden
exports.ef_lib:IsMenuOpen()                        -- Status prüfen
exports.ef_lib:GetUISettingsMenu()                 -- UI-Einstellungen als Menü-Item
exports.ef_lib:UpdateMenuItem(id, updates)          -- Item zur Laufzeit aktualisieren
exports.ef_lib:NavigateMenu(action)                 -- Programmatische Navigation

-- Dialoge (blockierend)
exports.ef_lib:InputDialog(title, fields)           -- Eingabe-Dialog → table|nil
exports.ef_lib:AlertDialog(data)                    -- Bestätigungs-Dialog → 'confirm'|'cancel'

-- Context Menu (ox_lib Kompatibilität)
exports.ef_lib:RegisterContext(data)                -- Context Menu registrieren
exports.ef_lib:ShowContext(id)                      -- Registriertes Context Menu anzeigen
exports.ef_lib:ContextMenu(data)                    -- Registrieren + Anzeigen in einem Aufruf

-- Notifications
exports.ef_lib:SendNotification(type, title, message, duration)

-- UI Config
exports.ef_lib:SetConfig(config)
exports.ef_lib:SetAccentColor(hexColor)

-- Button Hints
exports.ef_lib:ShowHint(key, label, id, icon, position)
exports.ef_lib:SetHintPosition(position)
exports.ef_lib:HideHint(id)
exports.ef_lib:HideAllHints()

-- Minigames
exports.ef_lib:Minigame(gameType, difficulty, retries)   -- difficulty darf auch eine Options-Tabelle sein; gibt success, result zurück
exports.ef_lib:SkillCheck(difficulty, keys)         -- Timing-Ring → boolean
exports.ef_lib:IsSkillCheckActive()
exports.ef_lib:CancelSkillCheck()

-- Anfragen
exports.ef_lib:Request(data)                        -- → accepted, 'accept'|'decline'|'timeout'

-- Ereignis-Banner
exports.ef_lib:Banner(data)

-- Abklingzeiten und Cache
exports.ef_lib:Cooldown(key, ms)                    -- → free, remaining
exports.ef_lib:GetCooldown(key)                     -- → ms
exports.ef_lib:ClearCooldown(key)
exports.ef_lib:GetCache(key)                        -- playerId, serverId, ped, vehicle, seat, weapon

-- ProgressBar
exports.ef_lib:ProgressBar(data)                    -- Fortschrittsanzeige → boolean
exports.ef_lib:ProgressCircle(data)                 -- dasselbe als Fortschrittskreis → boolean
exports.ef_lib:IsProgressBarActive()                -- Status prüfen
exports.ef_lib:CancelProgressBar()                  -- Progressbar abbrechen

-- Zonen
exports.ef_lib:CreateSphereZone(data)               -- Sphere Zone erstellen → zone
exports.ef_lib:CreateBoxZone(data)                   -- Box Zone erstellen → zone

-- Utilities
exports.ef_lib:RequestModel(model, timeout)          -- Model laden → boolean
exports.ef_lib:RequestAnimDict(dict, timeout)        -- AnimDict laden → boolean

-- Geo Helpers
exports.ef_lib:GetClosestPlayer(coords, radius)                  -- → id, ped, coords
exports.ef_lib:GetNearbyPlayers(coords, radius, includeSelf)     -- → table[]
exports.ef_lib:GetClosestVehicle(coords, radius, includeSelf)    -- → vehicle, coords
```

**Server:**
```lua
-- Callback System
exports.ef_lib:RegisterCallback(name, handler)
exports.ef_lib:UnregisterCallback(name)

-- Notifications
exports.ef_lib:SendNotification(source, type, title, message, duration)
exports.ef_lib:SendNotificationToAll(type, title, message, duration)

-- Menu Control
exports.ef_lib:OpenMenuForPlayer(source, menuData)
exports.ef_lib:CloseMenuForPlayer(source)

-- Anfragen
exports.ef_lib:Request(source, data)                -- → accepted, 'accept'|'decline'|'timeout'

-- Ereignis-Banner
exports.ef_lib:Banner(source, data)                 -- -1 für alle

-- Abklingzeiten
exports.ef_lib:Cooldown(key, ms)                    -- → free, remaining
exports.ef_lib:GetCooldown(key)
exports.ef_lib:ClearCooldown(key)

-- Versionscheck
exports.ef_lib:CheckVersion(label, repo)            -- Banner + Hinweis auf neues Release
```

---

## Projektstruktur

```
ef_lib/
├── config.lua              # Konfiguration
├── fxmanifest.lua          # Resource Manifest
├── example.lua             # Beispiel-Script
├── DOCUMENTATION.md        # Diese Datei
├── shared/
│   ├── locale.lua          # Englische Texte für Config.Locale = 'en'
│   └── cooldown.lua        # Abklingzeiten (Client und Server)
├── client/
│   ├── main.lua            # Client: Menu, Callbacks, Dialoge, Hints, Zones, Minigames, Skillcheck, ProgressBar
│   ├── cache.lua           # Cache und ef_lib:cache-Event
│   ├── request.lua         # Anfragen mit Annehmen und Ablehnen
│   └── vehicleProperties.lua
├── server/
│   └── main.lua            # Server: Callbacks, Notifications, Menu Control, Anfragen, Versionscheck
└── web/
    ├── src/                # Vue.js Quellcode
    │   ├── components/     # UI Komponenten (Menu, InputDialog, AlertDialog, Notifications, etc.)
    │   ├── stores/         # Pinia Stores (menu, dialog, notifications, settings)
    │   └── composables/    # NUI Kommunikation (fetchNui, useNuiEvent)
    └── dist/               # Gebaute Dateien (automatisch generiert)
```

---

## Minigame System

Vier Minispiele als Skill-Checks. Der Aufruf blockiert den aktuellen Thread und gibt zwei Werte zurück: `true` oder `false` und eine Tabelle mit Details.

### Grundnutzung

```lua
local success, result = exports.ef_lib:Minigame('lockpick', 'medium')

if success then
    print(('Geschafft in %.1f s mit %d Fehlversuchen'):format(result.time, result.misses))
end
```

`result` enthält `success`, `time` (Sekunden bis zum Ende) und `misses` (Fehlversuche). Damit lassen sich Ergebnisse abstufen, etwa eine Wunde, die bei vielen Fehlversuchen nur halb versorgt ist.

### Parameter

| Parameter | Typ | Pflicht | Beschreibung |
|-----------|-----|---------|-------------|
| `gameType` | string | ja | `'lockpick'`, `'safedial'`, `'reactionchain'` oder `'wires'` |
| `difficulty` | string oder table | nein | `'easy'`, `'medium'`, `'hard'`, `'extreme'` (Standard `'medium'`), oder eine Options-Tabelle |
| `retries` | number | nein | Eigene Anzahl Versuche, nur wenn `difficulty` ein String ist |

Mit einer Options-Tabelle lässt sich jeder Wert der Schwierigkeitsstufe einzeln überschreiben. Unbekannte Schlüssel und falsche Typen werden ignoriert.

```lua
local success = exports.ef_lib:Minigame('lockpick', {
    difficulty = 'hard',
    time = 60,      -- Sekunden
    retries = 5,
    pins = 4,
    sound = false,  -- Klänge aus
})
```

Für alle Spiele gelten `difficulty`, `time`, `retries` und `sound` (Standard `true`).

Ein Fehlversuch kostet einen Versuch, der Fortschritt bleibt. Sind alle Versuche aufgebraucht oder ist die Zeit um, endet das Spiel als Fehlschlag. `ESC` bricht ab.

### Schloss knacken (`lockpick`)

Maustaste oder `W` gedrückt halten erzeugt Spannung. Jeder Pin setzt sich mit `SPACE` nur, wenn er in der grünen Zone ist und die Spannung im markierten Bereich liegt. Mit der richtigen Spannung wird der aktive Pin langsamer. Zu viel Spannung lässt den Pick abrutschen, dann fällt der zuletzt gesetzte Pin zurück.

| Schwierigkeit | `pins` | `zone` (px) | `speed` | `tension` (Breite) | `time` | `retries` |
|---|---|---|---|---|---|---|
| easy | 3 | 56 | 1.3 | 0.34 | 40 | 4 |
| medium | 5 | 42 | 1.8 | 0.26 | 35 | 3 |
| hard | 6 | 32 | 2.4 | 0.2 | 30 | 2 |
| extreme | 7 | 24 | 3.0 | 0.15 | 25 | 1 |

### Tresor öffnen (`safedial`)

Drehen mit `A`/`D` oder dem Mausrad, prüfen mit `SPACE`. Die Kombination ist versteckt. In der richtigen Drehrichtung wird das Rad nahe der richtigen Zahl schwerer, leuchtet auf und klickt hörbar. Die Richtung wechselt pro Zahl, begonnen wird rechts herum.

Kennt der Spieler die Kombination, etwa von einem gefundenen Zettel, gibt das Script sie mit `code` mit. Sie steht dann als Notiz im Spiel.

```lua
exports.ef_lib:Minigame('safedial', { difficulty = 'medium', code = { 12, 5, 27 } })
```

| Schwierigkeit | `codes` | `tolerance` (±) | `numbers` | `time` | `retries` |
|---|---|---|---|---|---|
| easy | 2 | 1 | 20 | 45 | 4 |
| medium | 3 | 1 | 30 | 45 | 3 |
| hard | 3 | 0 | 40 | 40 | 2 |
| extreme | 4 | 0 | 50 | 40 | 1 |

### Reaktionskette (`reactionchain`)

Um ein Feld zieht sich ein Ring zusammen. Die Taste des Felds drücken, wenn der Ring den Rand trifft. Jedes Feld hat ein eigenes Symbol. Die Tasten sind frei wählbar, zwei bis sechs Stück.

```lua
exports.ef_lib:Minigame('reactionchain', { difficulty = 'medium', keys = { 'W', 'A', 'S', 'D' } })
```

| Schwierigkeit | `notes` (Treffer) | `approach` (ms) | `window` (± ms) | `interval` (ms) | `keys` | `time` | `retries` |
|---|---|---|---|---|---|---|---|
| easy | 8 | 1400 | 220 | 900 | 1 2 3 | 40 | 4 |
| medium | 12 | 1150 | 180 | 700 | 1 2 3 4 | 35 | 3 |
| hard | 16 | 950 | 150 | 520 | 1 2 3 4 | 30 | 2 |
| extreme | 20 | 800 | 120 | 420 | 1 2 3 4 | 28 | 1 |

### Kabel verbinden (`wires`)

Jedes Kabel links mit der Maus zum passenden Anschluss rechts ziehen. Ab `hard` zeigt die rechte Seite nur Symbole, keine Farben.

| Schwierigkeit | `wires` | `symbolsOnly` | `time` | `retries` |
|---|---|---|---|---|
| easy | 4 | false | 30 | 4 |
| medium | 5 | false | 25 | 3 |
| hard | 6 | true | 25 | 2 |
| extreme | 8 | true | 25 | 1 |

### Praxisbeispiele

```lua
-- Fahrzeug aufbrechen
RegisterCommand('lockpick', function()
    local success = exports.ef_lib:Minigame('lockpick', 'hard')
    if success then
        exports.ef_lib:SendNotification('success', 'Aufgebrochen', 'Fahrzeug wurde geöffnet')
    else
        exports.ef_lib:SendNotification('error', 'Fehlgeschlagen', 'Das Schloss hat sich verklemmt')
    end
end)

-- Tresor mit bekanntem Code aus einem Item
local success = exports.ef_lib:Minigame('safedial', { difficulty = 'hard', code = noteItem.metadata.code })

-- Stromkasten reparieren, Qualität nach Fehlversuchen
local success, result = exports.ef_lib:Minigame('wires', 'medium')
if success then
    TriggerServerEvent('power:repaired', result.misses == 0 and 'sauber' or 'provisorisch')
end
```

---

## ProgressBar System

Das ProgressBar-System bietet eine blockierende Fortschrittsanzeige mit optionaler Animation, Prop und Cancel-Möglichkeit. Der Spieler behält die Kamera-/Bewegungskontrolle (kein NUI-Focus nötig).

### Grundnutzung

```lua
-- Einfache Progressbar
local completed = exports.ef_lib:ProgressBar({
    label = 'Fahrzeug reparieren...',
    duration = 5000,
})

if completed then
    -- Aktion abgeschlossen
else
    -- Abgebrochen
end
```

### Vollständige Parameter

```lua
local completed = exports.ef_lib:ProgressBar({
    label = 'Motor reparieren...',          -- Text der angezeigt wird
    duration = 8000,                         -- Dauer in Millisekunden
    icon = 'fa-wrench',                      -- FontAwesome Icon (optional)
    canCancel = true,                        -- Abbrechbar mit X-Taste (default: false)
    cancelKey = 'X',                         -- Cancel-Taste (default: 'X')
    anim = {                                 -- Animation (optional)
        dict = 'mini@repair',
        clip = 'fixing_a_player',
        flag = 49,                           -- Anim flags (default: 49)
        blendIn = 3.0,                       -- Blend-In Speed (default: 3.0)
        blendOut = 1.0,                      -- Blend-Out Speed (default: 1.0)
    },
    prop = {                                 -- Prop zum Anhängen (optional)
        model = 'prop_tool_wrench',
        bone = 60309,                        -- Bone ID (default: SKEL_R_Hand / 60309)
        pos = vector3(0.0, 0.0, 0.0),       -- Offset Position
        rot = vector3(0.0, 0.0, 0.0),       -- Offset Rotation
    },
    disableControls = {                      -- Controls deaktivieren (optional)
        move = true,                         -- Bewegung (WASD/Sprint)
        car = false,                         -- Fahrzeug-Steuerung
        combat = true,                       -- Waffen/Angriff
        mouse = false,                       -- Kamera/Maus
    },
})
```

### Hilfsfunktionen

```lua
-- Prüfen ob eine Progressbar aktiv ist
local active = exports.ef_lib:IsProgressBarActive()

-- Aktive Progressbar programmatisch abbrechen
local wasCancelled = exports.ef_lib:CancelProgressBar()
```

### Server-seitige Events

```lua
-- Progressbar für einen Spieler starten
TriggerClientEvent('ef_lib:progressBar', source, {
    label = 'Verarbeitung...',
    duration = 3000,
})

-- Aktive Progressbar abbrechen
TriggerClientEvent('ef_lib:cancelProgressBar', source)
```

### Praxisbeispiele

```lua
-- Fahrzeug reparieren mit Animation und Prop
RegisterCommand('repair', function()
    local completed = exports.ef_lib:ProgressBar({
        label = 'Fahrzeug reparieren...',
        duration = 10000,
        icon = 'fa-wrench',
        canCancel = true,
        anim = { dict = 'mini@repair', clip = 'fixing_a_player' },
        prop = { model = 'prop_tool_wrench' },
        disableControls = { move = true, combat = true },
    })
    if completed then
        local veh = GetClosestVehicle(GetEntityCoords(PlayerPedId()), 5.0, 0, 70)
        if DoesEntityExist(veh) then
            SetVehicleFixed(veh)
        end
        exports.ef_lib:SendNotification('success', 'Repariert', 'Fahrzeug wurde repariert')
    else
        exports.ef_lib:SendNotification('error', 'Abgebrochen', 'Reparatur abgebrochen')
    end
end)

-- Medizinische Behandlung
RegisterCommand('treat', function()
    local completed = exports.ef_lib:ProgressBar({
        label = 'Patienten behandeln...',
        duration = 6000,
        icon = 'fa-heart-pulse',
        disableControls = { move = true, combat = true },
    })
    if completed then
        TriggerServerEvent('medical:treatPatient', targetId)
    end
end)
```

### Fortschrittskreis

Für kurze Aktionen wie Durchsuchen oder Kabel anschließen. Gleiche Optionen und Rückgabe wie `ProgressBar`, nur als Ziffernblatt mit 36 Strichen, Symbol in der Mitte und Text daneben. `IsProgressBarActive` und `CancelProgressBar` gelten auch hier.

```lua
local done = exports.ef_lib:ProgressCircle({
    label = 'Ladekabel anschließen',
    duration = 6000,
    icon = 'plug',
    canCancel = true,
})
```

---

## Dialog System

Modale Dialoge die den aktuellen Thread blockieren und auf Benutzereingabe warten. Funktioniert auch wenn ein Menü im Hintergrund geöffnet ist — der Cursor wird automatisch aktiviert und danach wiederhergestellt.

### InputDialog

Öffnet einen Dialog mit einem oder mehreren Eingabefeldern. Blockiert den Thread bis der Benutzer bestätigt oder abbricht.

```lua
local result = exports.ef_lib:InputDialog('Dialog Titel', {
    { type = 'input', label = 'Name', placeholder = 'Eingabe...', required = true },
    { type = 'number', label = 'Menge', min = 1, max = 100, default = 1 },
    { type = 'checkbox', label = 'Bestätigung', checked = false },
    { type = 'select', label = 'Auswahl', options = {
        { label = 'Option A', value = 'a' },
        { label = 'Option B', value = 'b' },
    }},
    { type = 'slider', label = 'Prozent', min = 0, max = 100, step = 5, default = 50 },
    { type = 'textarea', label = 'Beschreibung', placeholder = 'Text eingeben...' },
    { type = 'color', label = 'Lackfarbe' },
    { type = 'date', label = 'Zulassung bis', min = '2026-01-01', default = '2026-12-24' },
    { type = 'multi-select', label = 'Ausstattung', options = {
        { label = 'Sondersignal', value = 'signal', icon = 'tower-broadcast' },
        { label = 'Funk', value = 'radio', icon = 'walkie-talkie' },
    }},
})

if not result then
    -- Dialog wurde abgebrochen (ESC / Abbrechen)
    return
end

-- result ist ein Array in Feld-Reihenfolge
local name = result[1]       -- string
local amount = result[2]     -- number
local confirmed = result[3]  -- boolean
local selected = result[4]   -- any (value)
local percent = result[5]    -- number
local text = result[6]       -- string
local color = result[7]      -- '#f0500a'
local date = result[8]       -- '2026-12-24'
local extras = result[9]     -- { 'signal', 'radio' }
```

**Wichtig:** `InputDialog` blockiert den aktuellen Thread. Verwende es in `CreateThread` oder Event-Handlern.

#### Feld-Typen

| Typ | Beschreibung | Zusätzliche Parameter |
|-----|-------------|----------------------|
| `input` | Textfeld | `placeholder`, `required`, `default` |
| `number` | Zahlenfeld | `min`, `max`, `step`, `placeholder`, `required`, `default` |
| `checkbox` | Checkbox | `checked`, `default` |
| `select` | Dropdown-Auswahl | `options` (Array von `{label, value}` oder strings), `default` |
| `slider` | Schieberegler | `min`, `max`, `step`, `default` |
| `textarea` | Mehrzeiliges Textfeld | `placeholder`, `required`, `default` |
| `color` | Farbkacheln, gibt den Hex-Wert zurück | `options` (Liste von Hex-Werten, Standard sind 8 Farben), `default` |
| `date` | Feld mit aufklappendem Kalender, gibt `'YYYY-MM-DD'` zurück | `min`, `max` (als `'YYYY-MM-DD'`), `placeholder`, `required`, `default` |
| `multi-select` | Kacheln zum An- und Abwählen, gibt eine Liste der Werte zurück | `options` (`{label, value, icon?}` oder strings), `required` (mindestens eine), `default` (Liste) |

#### Rückgabewert

- `table` — Array der Werte in Feld-Reihenfolge (bei Bestätigung)
- `nil` — Dialog wurde abgebrochen

### AlertDialog

Öffnet einen Bestätigungs-/Warnungsdialog. Blockiert den Thread bis der Benutzer bestätigt oder abbricht.

```lua
local result = exports.ef_lib:AlertDialog({
    header = 'Löschen bestätigen',
    content = 'Soll der Eintrag wirklich gelöscht werden? Dies kann nicht rückgängig gemacht werden.',
    cancel = true,                      -- Abbrechen-Button anzeigen (Standard: true)
    centered = true,                    -- Text zentrieren (Standard: true)
    confirmLabel = 'Ja, löschen',       -- Text des Bestätigungs-Buttons (Standard: 'Bestätigen')
    cancelLabel = 'Nein, abbrechen',    -- Text des Abbruch-Buttons (Standard: 'Abbrechen')
})

if result == 'confirm' then
    -- Benutzer hat bestätigt
else
    -- Benutzer hat abgebrochen
end
```

#### Rückgabewert

- `'confirm'` — Benutzer hat bestätigt
- `'cancel'` — Benutzer hat abgebrochen

### Praxisbeispiele

```lua
-- Outfit speichern mit Namenseingabe
CreateThread(function()
    local result = exports.ef_lib:InputDialog('Outfit Speichern', {
        { type = 'input', label = 'Outfit Name', placeholder = 'Name eingeben...', required = true },
    })

    if not result or not result[1] or result[1] == '' then return end

    local outfitName = result[1]
    TriggerServerEvent('myResource:saveOutfit', outfitName)
end)

-- Bestätigungsdialog vor einer gefährlichen Aktion
CreateThread(function()
    local result = exports.ef_lib:AlertDialog({
        header = 'Fahrzeug löschen?',
        content = 'Das Fahrzeug wird dauerhaft entfernt.',
    })

    if result == 'confirm' then
        TriggerServerEvent('myResource:deleteVehicle', vehicleId)
    end
end)
```

---

## Context Menu System (ox_lib Kompatibilität)

Bietet das `registerContext`/`showContext` Muster für einfache Migration von ox_lib. Unterstützt `onSelect`-Callbacks direkt in den Optionen.

### Context Menu registrieren und anzeigen

```lua
-- Registrieren + Anzeigen in einem Aufruf
exports.ef_lib:ContextMenu({
    id = 'my_context',
    title = 'Aktionen',
    options = {
        {
            title = 'Reparieren',
            description = 'Fahrzeug reparieren',
            icon = 'fa-wrench',
            onSelect = function()
                print('Reparieren gewählt')
            end,
        },
        {
            title = 'Abschleppen',
            icon = 'fa-truck',
            disabled = false,
            onSelect = function()
                print('Abschleppen gewählt')
            end,
        },
    }
})
```

### Getrennt registrieren und anzeigen

```lua
-- Einmalig registrieren
exports.ef_lib:RegisterContext({
    id = 'shop_menu',
    title = 'Shop',
    options = { ... }
})

-- Später anzeigen
exports.ef_lib:ShowContext('shop_menu')
```

### Migration von ox_lib

```lua
-- VORHER (ox_lib):
lib.registerContext({ id = 'menu', title = 'Titel', options = { ... } })
lib.showContext('menu')

-- NACHHER (ef_lib):
exports.ef_lib:RegisterContext({ id = 'menu', title = 'Titel', options = { ... } })
exports.ef_lib:ShowContext('menu')
-- Oder zusammen:
exports.ef_lib:ContextMenu({ id = 'menu', title = 'Titel', options = { ... } })
```

---

## Zone System

Einfaches Zone-System mit Enter/Exit/Inside-Callbacks. Prüft alle 300ms die Spielerposition.

**Hinweis:** Zonen werden automatisch entfernt, wenn die erstellende Resource stoppt. Sie lässt sich also neu starten, ohne ef_lib mit neu zu starten.

### Sphere Zone erstellen

```lua
local zone = exports.ef_lib:CreateSphereZone({
    coords = vector3(100.0, 200.0, 30.0),
    radius = 5.0,
    onEnter = function(self)
        print('Zone betreten')
        exports.ef_lib:ShowHint('E', 'Interagieren', 'zone_hint')
    end,
    onExit = function(self)
        print('Zone verlassen')
        exports.ef_lib:HideHint('zone_hint')
    end,
    inside = function(self)
        -- Wird jeden Tick aufgerufen solange der Spieler in der Zone ist
    end,
})

-- Zone entfernen
zone:remove()
```

### Box Zone erstellen

Box Zones verwenden intern die größte Dimension als Radius (vereinfachte Prüfung).

```lua
local zone = exports.ef_lib:CreateBoxZone({
    coords = vector3(100.0, 200.0, 30.0),
    size = vector3(4.0, 6.0, 2.0),
    onEnter = function(self)
        print('Box-Zone betreten')
    end,
    onExit = function(self)
        print('Box-Zone verlassen')
    end,
})
```

---

## Utility Exports

### Model laden

Lädt ein Modell asynchron mit Timeout. Gibt `true` zurück wenn erfolgreich geladen.

```lua
local success = exports.ef_lib:RequestModel('prop_tool_wrench')
-- Oder mit Hash:
local success = exports.ef_lib:RequestModel(joaat('prop_tool_wrench'))
-- Mit Timeout (Standard: 10000ms):
local success = exports.ef_lib:RequestModel('prop_tool_wrench', 5000)
```

### Animation Dictionary laden

Lädt ein Animation Dictionary asynchron mit Timeout.

```lua
local success = exports.ef_lib:RequestAnimDict('mini@repair')
-- Mit Timeout:
local success = exports.ef_lib:RequestAnimDict('mini@repair', 5000)
```

### Hint Position setzen

```lua
exports.ef_lib:SetHintPosition('bottom-left')  -- Standard-Position
```

---

## Geo Helpers (Client)

Drop-in-Ersatz für ox_lib-Geo-Natives. Alle Funktionen sind client-seitig und arbeiten mit `vector3`-Koordinaten und Metern als Radius.

### `GetClosestPlayer(coords, radius)`

Findet den **nächstgelegenen Spieler** (außer dem eigenen) innerhalb des Radius.

**Parameter:**

| Name | Typ | Beschreibung |
|---|---|---|
| `coords` | vector3 | Mittelpunkt der Suche |
| `radius` | number | Maximaler Abstand in Metern |

**Rückgabe:** `playerId, ped, coords` — alles `nil` wenn niemand in Reichweite.

```lua
local pid, ped, pcoords = exports.ef_lib:GetClosestPlayer(GetEntityCoords(PlayerPedId()), 5.0)
if pid then
    print(('Nächster Spieler: %s, Abstand: %.2fm'):format(GetPlayerName(pid), #(pcoords - GetEntityCoords(PlayerPedId()))))
end
```

### `GetNearbyPlayers(coords, radius, includeSelf)`

Liefert **alle Spieler im Radius** als sortiertes Array (nach Abstand aufsteigend).

**Parameter:**

| Name | Typ | Beschreibung |
|---|---|---|
| `coords` | vector3 | Mittelpunkt |
| `radius` | number | Maximaler Abstand in Metern |
| `includeSelf` | boolean? | Eigenen Spieler einschließen (default: `false`) |

**Rückgabe:** `table[]` mit Einträgen `{ id, ped, coords, distance }`.

```lua
local nearby = exports.ef_lib:GetNearbyPlayers(GetEntityCoords(PlayerPedId()), 10.0, false)
for i, p in ipairs(nearby) do
    print(('#%d: %s @ %.2fm'):format(i, GetPlayerName(p.id), p.distance))
end
```

### `GetClosestVehicle(coords, radius, includeSelf)`

Findet das **nächstgelegene Fahrzeug** im Radius. Nutzt intern `GetGamePool('CVehicle')`.

**Parameter:**

| Name | Typ | Beschreibung |
|---|---|---|
| `coords` | vector3 | Mittelpunkt |
| `radius` | number | Maximaler Abstand in Metern |
| `includeSelf` | boolean? | Eigenes Fahrzeug einschließen (default: `false`) |

**Rückgabe:** `vehicle, coords` — beide `nil` wenn keins in Reichweite.

```lua
local veh, vcoords = exports.ef_lib:GetClosestVehicle(GetEntityCoords(PlayerPedId()), 8.0, false)
if veh then
    print(('Nächstes Fahrzeug: %s'):format(GetDisplayNameFromVehicleModel(GetEntityModel(veh))))
end
```

---

## Radial Menu (Schnellaktionen)

Hold-to-trigger Radial-Wheel im Stil eines Weapon-Wheels. Eine Taste halten öffnet das Wheel, die Maus-Richtung vom Bildschirmcenter aus bestimmt den aktiven Slice. Loslassen feuert die Aktion. Optional kann auch per Linksklick bestätigt und in Submenüs navigiert werden.

### Exports

```lua
exports.ef_lib:OpenRadial(data)   -- öffnet das Radial (nicht-blockierend)
exports.ef_lib:CloseRadial()      -- schließt das Radial, löst onSelect aus
```

### Datenstruktur

| Feld | Typ | Beschreibung |
|---|---|---|
| `items` | table | Liste der Slices (max. 8 pro Ebene) |
| `onSelect` | function(id) | Callback, der mit der ID des gewählten Items aufgerufen wird |

Jedes Item:

| Feld | Typ | Beschreibung |
|---|---|---|
| `id` | string | Eindeutige ID (bei Submenüs empfohlen: `parent:child` Konvention) |
| `label` | string | Anzeigetext unter dem Icon |
| `icon` | string (optional) | FontAwesome-Icon (z.B. `'fa-phone'`, `'fa-solid fa-key'`) |
| `submenu` | table (optional) | Verschachtelte Items — verwandelt den Slice zu einem Drill-Down |
| `keepOpen` | boolean (optional) | Nach dem Auslösen bleibt das Radial offen (Cursor-Modus); nur sinnvoll auf End-Items |

### Verhalten

- **Maus-Richtung** vom Bildschirmcenter aus bestimmt den aktiven Slice
- **Dead-Zone** im Zentrum (innerer Kreis) → kein Slice aktiv
- **Hold-Taste loslassen** → `onSelect(id)` wird mit dem aktiven Item aufgerufen. Ohne aktiven Slice (Dead-Zone): kein Callback (Abbruch)
- **Linksklick auf End-Item** → triggert die Aktion sofort, schließt das Radial
- **Linksklick auf Submenu-Item** → öffnet das Submenü (Drill-Down)
- **Linksklick im Zentrum** (im Submenü) → eine Ebene zurück
- **Submenu-Indikator**: drei kleine Punkte (`fa-ellipsis`) unter dem Label

### Cursor-Modus (keepOpen)

Setzt ein End-Item `keepOpen = true`, läuft beim Auslösen `onSelect(id)` und das Radial **bleibt offen** im Cursor-Modus. Hold-to-trigger ist dann abgeschaltet — nur Linksklick triggert weitere Items. Geschlossen wird explizit durch:

- **ESC**
- **Linksklick im Zentrum** auf oberster Ebene (im Submenü navigiert es weiter zurück)
- Auswahl eines Items **ohne** `keepOpen`

Beispiel für eine Aktions-Serie (mehrere Handfesseln-Aktionen direkt nacheinander):

```lua
{
    id = 'cuff', label = 'Handfesseln', icon = 'fa-handcuffs',
    submenu = {
        { id = 'cuff:apply',   label = 'Anlegen',  icon = 'fa-lock',          keepOpen = true },
        { id = 'cuff:drag',    label = 'Ziehen',   icon = 'fa-hand-fist',     keepOpen = true },
        { id = 'cuff:release', label = 'Lösen',    icon = 'fa-lock-open' },
    }
}
```

### Typisches Setup

```lua
RegisterCommand('+quick_actions', function()
    exports.ef_lib:OpenRadial({
        items = {
            { id = 'phone', label = 'Telefon', icon = 'fa-phone' },
            {
                id = 'vehicle', label = 'Fahrzeug', icon = 'fa-car',
                submenu = {
                    { id = 'vehicle:light',  label = 'Licht',     icon = 'fa-lightbulb' },
                    { id = 'vehicle:engine', label = 'Motor',     icon = 'fa-key' },
                    { id = 'vehicle:trunk',  label = 'Kofferraum',icon = 'fa-car-rear' },
                }
            },
            { id = 'inventory', label = 'Inventar', icon = 'fa-box' },
        },
        onSelect = function(id)
            if id == 'phone' then TriggerEvent('phone:open')
            elseif id == 'vehicle:light' then TriggerEvent('vehicle:toggleLights')
            elseif id == 'vehicle:engine' then TriggerEvent('vehicle:toggleEngine')
            elseif id == 'vehicle:trunk' then TriggerEvent('vehicle:openTrunk')
            elseif id == 'inventory' then TriggerEvent('inventory:open')
            end
        end
    })
end, false)

RegisterCommand('-quick_actions', function()
    exports.ef_lib:CloseRadial()
end, false)

RegisterKeyMapping('+quick_actions', 'Schnellaktionen-Wheel', 'keyboard', 'Z')
```

### Hinweise

- Maximal **8 Items pro Ebene** — überschüssige Items werden abgeschnitten. Wenn mehr Aktionen benötigt werden, gruppiere sie in Submenüs.
- Submenüs sind **beliebig tief** verschachtelbar.
- Das Radial gibt **Tastatur-Inputs** durch (`SetNuiFocusKeepInput(true)`) — der Spieler kann sich während des offenen Wheels weiterbewegen. Maus geht an die UI.
- Beim Klick-Selfclose ist der NUI-Focus sauber freigegeben — der Lua-`CloseRadial()`-Call ist dann ein No-Op.

---

## Skillcheck

Ein Punkt läuft einmal um den Ring. Der Spieler drückt die angezeigte Taste, solange der Punkt im hellen Bogen ist. Er kann dabei weiterlaufen. Der erste falsche Druck oder eine Runde ohne Druck lässt den ganzen Check scheitern.

```lua
local ok = exports.ef_lib:SkillCheck('medium')                          -- eine Stufe, Taste E
local ok = exports.ef_lib:SkillCheck({ 'easy', 'medium', 'hard' })      -- drei Stufen hintereinander
local ok = exports.ef_lib:SkillCheck('hard', { 'W', 'A', 'S', 'D' })   -- jede Stufe fragt eine dieser Tasten ab
local ok = exports.ef_lib:SkillCheck({ { zone = 50, speed = 2.0 } })   -- eigene Stufe: Bogen in Grad, Sekunden pro Runde
```

| Stufe | Bogen | Sekunden pro Runde |
|---|---|---|
| `easy` | 60° | 1,6 |
| `medium` | 45° | 1,25 |
| `hard` | 30° | 1,0 |
| `extreme` | 20° | 0,8 |

`exports.ef_lib:IsSkillCheckActive()` sagt, ob gerade einer läuft, `exports.ef_lib:CancelSkillCheck()` bricht ihn ab (Ergebnis `false`).

---

## Anfragen (Request)

Eine Frage, die der Spieler mit einer Taste beantwortet, ohne dass er die Kontrolle verliert: Einladungen, Durchsuchen, etwas übergeben. Die Tasten sind Key Mappings (Standard `Y` und `N`, siehe `Config.RequestKeys`), Spieler können sie in den FiveM-Tastenbelegungen ändern. Die Anzeige zeigt immer die belegte Taste.

```lua
-- Client
local accepted, answer = exports.ef_lib:Request({
    title = 'Einladung in die Feuerwache 3',
    message = 'Max Becker lädt dich in die Fraktion Feuerwehr ein.',
    icon = 'user-plus',        -- optional, Font-Awesome-Name
    duration = 15000,          -- optional, ms bis zur Zeitüberschreitung (Standard 15000)
    acceptLabel = 'Beitreten', -- optional
    declineLabel = 'Nein',     -- optional
})
-- accepted: true/false, answer: 'accept' | 'decline' | 'timeout'

-- Server: fragt einen Spieler und wartet auf seine Antwort
local accepted, answer = exports.ef_lib:Request(targetSource, { title = 'Durchsuchen erlauben?', message = 'Officer Weber möchte dich durchsuchen.' })
```

Kommt eine Anfrage, während noch eine offen ist, wartet sie, bis die erste beantwortet ist. Verlässt der Spieler den Server, gibt der Server-Export `false, 'timeout'` zurück.

---

## Ereignis-Banner

Für Momente, die mehr sind als eine Meldung: Beförderung, Einsatz beendet, Schichtbeginn. Eine Glaskarte mit Medaille erscheint im oberen Drittel und geht nach `duration` von selbst. Kommen mehrere, zeigt ef_lib sie nacheinander.

```lua
-- Client
exports.ef_lib:Banner({
    title = 'Befördert zum Oberbrandmeister',
    message = 'Feuer- und Rettungswache 1',  -- optional
    icon = 'medal',                          -- optional, Font-Awesome-Name
    stats = {                                -- optional, kleine Werte unter dem Text
        { label = 'Dienstzeit', value = '124 h' },
        { label = 'Einsätze', value = 87 },
    },
    duration = 5000,                         -- optional, ms (Standard 5000)
})

-- Server, -1 für alle Spieler
exports.ef_lib:Banner(source, { title = 'Einsatz beendet', message = 'B3 Wohnungsbrand, Grove Street' })
```

---

## Abklingzeiten (Cooldown)

Auf Client und Server. Die Schlüssel gelten pro aufrufender Resource, zwei Scripts kommen sich mit demselben Namen nicht in die Quere.

```lua
local free, remaining = exports.ef_lib:Cooldown(('rob:%d'):format(source), 60000)
if not free then
    return exports.ef_lib:SendNotification(source, 'error', 'Noch nicht', ('Wieder in %d s'):format(math.ceil(remaining / 1000)))
end

exports.ef_lib:GetCooldown(key)    -- verbleibende ms, 0 wenn frei
exports.ef_lib:ClearCooldown(key)  -- sofort freigeben
```

---

## Cache (Client)

ef_lib prüft alle 100 ms `playerId`, `serverId`, `ped`, `vehicle`, `seat` und `weapon` und meldet jede Änderung als Event. Das ist der günstige Weg, auf Einsteigen oder Waffe ziehen zu reagieren, ohne selbst eine Schleife zu bauen.

```lua
AddEventHandler('ef_lib:cache', function(key, value, old)
    if key == 'vehicle' and value then
        print('Eingestiegen in', value)
    end
end)

local vehicle = exports.ef_lib:GetCache('vehicle')  -- false, wenn zu Fuß
local all = exports.ef_lib:GetCache()
```

`vehicle`, `seat` und `weapon` sind `false` statt `nil`, wenn es nichts gibt. `GetCache` ist ein Export-Aufruf über Resource-Grenzen hinweg. In Code, der jeden Frame läuft, ist der Native (`PlayerPedId()`) schneller.

---

## Versionscheck (Server)

Druckt beim Start das EmergencyForge-Banner mit Name und Version und meldet in der Konsole, wenn es ein neueres Release gibt. Die eigene Version kommt aus `version` in der `fxmanifest.lua` des aufrufenden Scripts, die neueste aus `https://emergencyforge.de/api/versions/<name>`.

```lua
-- server.lua deines Scripts
exports.ef_lib:CheckVersion('Fraktionsgarage')
-- Heißt der Resource-Ordner anders als das Repo:
exports.ef_lib:CheckVersion('Fraktionsgarage', 'ef_fraktionsgarage')
```

Antwortet die Seite nicht oder kennt das Script nicht, kommt nur das Banner.

---

## Sprache

`Config.Locale = 'en'` stellt alle Texte von ef_lib selbst auf Englisch: Knöpfe, Steuerhinweise, Minispiele, Einstellungsmenü und die Konsolenmeldung des Versionschecks. Was dein Script übergibt (Titel, Labels, Meldungen), erscheint unverändert.
